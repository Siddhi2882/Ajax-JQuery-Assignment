'use strict'
document.getElementById("btn").onclick = function () {
    var data1 = document.getElementById("x1").value;
    var data2 = document.getElementById("x2").value;
    var data3 = document.getElementById("x3").value;

    console.log(isNaN(data1));
    console.log(data1);
    console.log(data2);
    console.log(data3);

    var msg = "";
    if (data1 == "" || data2 == "" || data3 == "") {
        msg = "plz enter all fields";
    } else if (isNaN(data1) || isNaN(data2) || isNaN(data3)) {
        msg = "all fields should be numberic values";
    } else if (data1 < 0 || data2 < 0 || data3 < 0) {
        msg = "all fields should be positive values";
    } else {
        var p = Number(data1);
        var c = Number(data2);
        var m = Number(data3);

         var total=p+c+m;
         var percentage=(total/300)*100;
         if(percentage>80)
         {
            var grade='I';
         }
         else{
            var grade='II';
         }

         document.getElementById("p1").innerHTML=total;
         document.getElementById("p2").innerHTML=percentage;
         document.getElementById("p3").innerHTML=grade;

         Highcharts.chart('container', {
            chart: {
                type: 'pie'
            },
            title: {
                text: 'PCM'
            },
            tooltip: {
                valueSuffix: '%'
            },
            subtitle: {
                text:
                'Source:<a href="https://www.mdpi.com/2072-6643/11/3/684/htm" target="_default">MDPI</a>'
            },
            plotOptions: {
                series: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: [{
                        enabled: true,
                        distance: 20
                    }, {
                        enabled: true,
                        distance: -40,
                        format: '{point.percentage:.1f}%',
                        style: {
                            fontSize: '1.2em',
                            textOutline: 'none',
                            opacity: 0.7
                        },
                        filter: {
                            operator: '>',
                            property: 'percentage',
                            value: 10
                        }
                    }]
                }
            },
            series: [
                {
                    name: 'Percentage',
                    colorByPoint: true,
                    data: [
                        {
                            name: 'Physics',
                            y: p
                        },
                        {
                            name: 'Chemistry',
                            sliced: true,
                            selected: true,
                            y: c
                        },
                        {
                            name: 'Maths',
                            y: m
                        }
                        
                    ]
                }
            ]
        });
        
    }
    document.getElementById("result").innerHTML = msg;
};